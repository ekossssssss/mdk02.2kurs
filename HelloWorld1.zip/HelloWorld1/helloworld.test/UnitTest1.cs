namespace helloworld.test
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            //Assert.Pass();
            using (var sw = new StringWriter())
            {
                Console.SetOut(sw);
                HelloWorld.Program.Mein();

                var result = sw .ToString().Trim();
                Assert.AreEqual(Expected, result);

                

            }
        }
    }
}