﻿namespace WindowsFormsApp3
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.start2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.start3 = new System.Windows.Forms.PictureBox();
            this.start1 = new System.Windows.Forms.PictureBox();
            this.checkpoint3 = new System.Windows.Forms.Label();
            this.checkpoint4 = new System.Windows.Forms.Label();
            this.checkpoint5 = new System.Windows.Forms.Label();
            this.checkpoint6 = new System.Windows.Forms.Label();
            this.checkpoint7 = new System.Windows.Forms.Label();
            this.checkpoint8 = new System.Windows.Forms.Label();
            this.checkpoint1 = new System.Windows.Forms.Label();
            this.checkpoint2 = new System.Windows.Forms.Label();
            this.pictureDrinks = new System.Windows.Forms.PictureBox();
            this.pictureEnergyBars = new System.Windows.Forms.PictureBox();
            this.pictureInformation = new System.Windows.Forms.PictureBox();
            this.pictureMedical = new System.Windows.Forms.PictureBox();
            this.pictureToilets = new System.Windows.Forms.PictureBox();
            this.Drinks = new System.Windows.Forms.Label();
            this.EnergyBars = new System.Windows.Forms.Label();
            this.Information = new System.Windows.Forms.Label();
            this.Medical = new System.Windows.Forms.Label();
            this.Toilets = new System.Windows.Forms.Label();
            this.header = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.start2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.start3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.start1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDrinks)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEnergyBars)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureInformation)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMedical)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureToilets)).BeginInit();
            this.SuspendLayout();
            // 
            // start2
            // 
            this.start2.Image = ((System.Drawing.Image)(resources.GetObject("start2.Image")));
            this.start2.Location = new System.Drawing.Point(297, 374);
            this.start2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.start2.Name = "start2";
            this.start2.Size = new System.Drawing.Size(38, 40);
            this.start2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.start2.TabIndex = 8;
            this.start2.TabStop = false;
            this.start2.Click += new System.EventHandler(this.start2_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(76, 35);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(352, 379);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // start3
            // 
            this.start3.Image = ((System.Drawing.Image)(resources.GetObject("start3.Image")));
            this.start3.Location = new System.Drawing.Point(115, 195);
            this.start3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.start3.Name = "start3";
            this.start3.Size = new System.Drawing.Size(38, 40);
            this.start3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.start3.TabIndex = 10;
            this.start3.TabStop = false;
            this.start3.Click += new System.EventHandler(this.start3_Click);
            // 
            // start1
            // 
            this.start1.Image = ((System.Drawing.Image)(resources.GetObject("start1.Image")));
            this.start1.Location = new System.Drawing.Point(207, 59);
            this.start1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.start1.Name = "start1";
            this.start1.Size = new System.Drawing.Size(38, 40);
            this.start1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.start1.TabIndex = 11;
            this.start1.TabStop = false;
            this.start1.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // checkpoint3
            // 
            this.checkpoint3.AutoSize = true;
            this.checkpoint3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint3.Location = new System.Drawing.Point(305, 239);
            this.checkpoint3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint3.Name = "checkpoint3";
            this.checkpoint3.Size = new System.Drawing.Size(30, 32);
            this.checkpoint3.TabIndex = 23;
            this.checkpoint3.Text = "3";
            this.checkpoint3.Click += new System.EventHandler(this.checkpoint3_Click);
            // 
            // checkpoint4
            // 
            this.checkpoint4.AutoSize = true;
            this.checkpoint4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint4.Location = new System.Drawing.Point(388, 325);
            this.checkpoint4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint4.Name = "checkpoint4";
            this.checkpoint4.Size = new System.Drawing.Size(30, 32);
            this.checkpoint4.TabIndex = 24;
            this.checkpoint4.Text = "4";
            this.checkpoint4.Click += new System.EventHandler(this.checkpoint4_Click);
            // 
            // checkpoint5
            // 
            this.checkpoint5.AutoSize = true;
            this.checkpoint5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint5.Location = new System.Drawing.Point(259, 374);
            this.checkpoint5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint5.Name = "checkpoint5";
            this.checkpoint5.Size = new System.Drawing.Size(30, 32);
            this.checkpoint5.TabIndex = 25;
            this.checkpoint5.Text = "5";
            this.checkpoint5.Click += new System.EventHandler(this.checkpoint5_Click);
            // 
            // checkpoint6
            // 
            this.checkpoint6.AutoSize = true;
            this.checkpoint6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint6.Location = new System.Drawing.Point(159, 341);
            this.checkpoint6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint6.Name = "checkpoint6";
            this.checkpoint6.Size = new System.Drawing.Size(30, 32);
            this.checkpoint6.TabIndex = 26;
            this.checkpoint6.Text = "6";
            this.checkpoint6.Click += new System.EventHandler(this.checkpoint6_Click);
            // 
            // checkpoint7
            // 
            this.checkpoint7.AutoSize = true;
            this.checkpoint7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint7.Location = new System.Drawing.Point(123, 272);
            this.checkpoint7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint7.Name = "checkpoint7";
            this.checkpoint7.Size = new System.Drawing.Size(30, 32);
            this.checkpoint7.TabIndex = 27;
            this.checkpoint7.Text = "7";
            this.checkpoint7.Click += new System.EventHandler(this.checkpoint7_Click);
            // 
            // checkpoint8
            // 
            this.checkpoint8.AutoSize = true;
            this.checkpoint8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint8.Location = new System.Drawing.Point(109, 158);
            this.checkpoint8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint8.Name = "checkpoint8";
            this.checkpoint8.Size = new System.Drawing.Size(30, 32);
            this.checkpoint8.TabIndex = 28;
            this.checkpoint8.Text = "8";
            this.checkpoint8.Click += new System.EventHandler(this.checkpoint8_Click);
            // 
            // checkpoint1
            // 
            this.checkpoint1.AutoSize = true;
            this.checkpoint1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint1.Location = new System.Drawing.Point(278, 50);
            this.checkpoint1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint1.Name = "checkpoint1";
            this.checkpoint1.Size = new System.Drawing.Size(30, 32);
            this.checkpoint1.TabIndex = 29;
            this.checkpoint1.Text = "1";
            this.checkpoint1.Click += new System.EventHandler(this.checkpoint1_Click);
            // 
            // checkpoint2
            // 
            this.checkpoint2.AutoSize = true;
            this.checkpoint2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.checkpoint2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.checkpoint2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.checkpoint2.Location = new System.Drawing.Point(317, 158);
            this.checkpoint2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.checkpoint2.Name = "checkpoint2";
            this.checkpoint2.Size = new System.Drawing.Size(30, 32);
            this.checkpoint2.TabIndex = 30;
            this.checkpoint2.Text = "2";
            this.checkpoint2.Click += new System.EventHandler(this.checkpoint2_Click);
            // 
            // pictureDrinks
            // 
            this.pictureDrinks.Image = global::WindowsFormsApp3.Properties.Resources.map_icon_drinks;
            this.pictureDrinks.Location = new System.Drawing.Point(563, 59);
            this.pictureDrinks.Name = "pictureDrinks";
            this.pictureDrinks.Size = new System.Drawing.Size(110, 96);
            this.pictureDrinks.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureDrinks.TabIndex = 31;
            this.pictureDrinks.TabStop = false;
            this.pictureDrinks.Click += new System.EventHandler(this.pictureDrinks_Click);
            // 
            // pictureEnergyBars
            // 
            this.pictureEnergyBars.Image = global::WindowsFormsApp3.Properties.Resources.map_icon_energy_bars;
            this.pictureEnergyBars.Location = new System.Drawing.Point(563, 175);
            this.pictureEnergyBars.Name = "pictureEnergyBars";
            this.pictureEnergyBars.Size = new System.Drawing.Size(110, 96);
            this.pictureEnergyBars.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureEnergyBars.TabIndex = 32;
            this.pictureEnergyBars.TabStop = false;
            // 
            // pictureInformation
            // 
            this.pictureInformation.Image = global::WindowsFormsApp3.Properties.Resources.map_icon_information;
            this.pictureInformation.Location = new System.Drawing.Point(563, 288);
            this.pictureInformation.Name = "pictureInformation";
            this.pictureInformation.Size = new System.Drawing.Size(110, 96);
            this.pictureInformation.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureInformation.TabIndex = 33;
            this.pictureInformation.TabStop = false;
            // 
            // pictureMedical
            // 
            this.pictureMedical.Image = global::WindowsFormsApp3.Properties.Resources.map_icon_medical;
            this.pictureMedical.Location = new System.Drawing.Point(563, 400);
            this.pictureMedical.Name = "pictureMedical";
            this.pictureMedical.Size = new System.Drawing.Size(110, 96);
            this.pictureMedical.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureMedical.TabIndex = 34;
            this.pictureMedical.TabStop = false;
            // 
            // pictureToilets
            // 
            this.pictureToilets.Image = global::WindowsFormsApp3.Properties.Resources.map_icon_toilets;
            this.pictureToilets.Location = new System.Drawing.Point(563, 514);
            this.pictureToilets.Name = "pictureToilets";
            this.pictureToilets.Size = new System.Drawing.Size(110, 96);
            this.pictureToilets.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureToilets.TabIndex = 35;
            this.pictureToilets.TabStop = false;
            // 
            // Drinks
            // 
            this.Drinks.AutoSize = true;
            this.Drinks.Location = new System.Drawing.Point(701, 93);
            this.Drinks.Name = "Drinks";
            this.Drinks.Size = new System.Drawing.Size(141, 20);
            this.Drinks.TabIndex = 36;
            this.Drinks.Text = "Стенд для питья";
            this.Drinks.Click += new System.EventHandler(this.label1_Click);
            // 
            // EnergyBars
            // 
            this.EnergyBars.AutoSize = true;
            this.EnergyBars.Location = new System.Drawing.Point(701, 215);
            this.EnergyBars.Name = "EnergyBars";
            this.EnergyBars.Size = new System.Drawing.Size(218, 20);
            this.EnergyBars.TabIndex = 37;
            this.EnergyBars.Text = "Энергетические батончики";
            // 
            // Information
            // 
            this.Information.AutoSize = true;
            this.Information.Location = new System.Drawing.Point(701, 325);
            this.Information.Name = "Information";
            this.Information.Size = new System.Drawing.Size(197, 20);
            this.Information.TabIndex = 38;
            this.Information.Text = "Информационный стенд";
            // 
            // Medical
            // 
            this.Medical.AutoSize = true;
            this.Medical.Location = new System.Drawing.Point(701, 436);
            this.Medical.Name = "Medical";
            this.Medical.Size = new System.Drawing.Size(84, 20);
            this.Medical.TabIndex = 39;
            this.Medical.Text = "Медпункт";
            // 
            // Toilets
            // 
            this.Toilets.AutoSize = true;
            this.Toilets.Location = new System.Drawing.Point(701, 550);
            this.Toilets.Name = "Toilets";
            this.Toilets.Size = new System.Drawing.Size(62, 20);
            this.Toilets.TabIndex = 40;
            this.Toilets.Text = "Туалет";
            // 
            // header
            // 
            this.header.AutoSize = true;
            this.header.Location = new System.Drawing.Point(574, 22);
            this.header.Name = "header";
            this.header.Size = new System.Drawing.Size(131, 20);
            this.header.TabIndex = 41;
            this.header.Text = "Название точки";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 622);
            this.Controls.Add(this.header);
            this.Controls.Add(this.Toilets);
            this.Controls.Add(this.Medical);
            this.Controls.Add(this.Information);
            this.Controls.Add(this.EnergyBars);
            this.Controls.Add(this.Drinks);
            this.Controls.Add(this.pictureToilets);
            this.Controls.Add(this.pictureMedical);
            this.Controls.Add(this.pictureInformation);
            this.Controls.Add(this.pictureEnergyBars);
            this.Controls.Add(this.pictureDrinks);
            this.Controls.Add(this.checkpoint2);
            this.Controls.Add(this.checkpoint8);
            this.Controls.Add(this.checkpoint7);
            this.Controls.Add(this.checkpoint6);
            this.Controls.Add(this.checkpoint5);
            this.Controls.Add(this.start1);
            this.Controls.Add(this.start3);
            this.Controls.Add(this.start2);
            this.Controls.Add(this.checkpoint3);
            this.Controls.Add(this.checkpoint4);
            this.Controls.Add(this.checkpoint1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.start2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.start3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.start1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDrinks)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureEnergyBars)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureInformation)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureMedical)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureToilets)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox start2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox start3;
        private System.Windows.Forms.PictureBox start1;
        private System.Windows.Forms.Label checkpoint3;
        private System.Windows.Forms.Label checkpoint4;
        private System.Windows.Forms.Label checkpoint5;
        private System.Windows.Forms.Label checkpoint6;
        private System.Windows.Forms.Label checkpoint7;
        private System.Windows.Forms.Label checkpoint8;
        private System.Windows.Forms.Label checkpoint1;
        private System.Windows.Forms.Label checkpoint2;
        private System.Windows.Forms.PictureBox pictureDrinks;
        private System.Windows.Forms.PictureBox pictureEnergyBars;
        private System.Windows.Forms.PictureBox pictureInformation;
        private System.Windows.Forms.PictureBox pictureMedical;
        private System.Windows.Forms.PictureBox pictureToilets;
        private System.Windows.Forms.Label Drinks;
        private System.Windows.Forms.Label EnergyBars;
        private System.Windows.Forms.Label Information;
        private System.Windows.Forms.Label Medical;
        private System.Windows.Forms.Label Toilets;
        private System.Windows.Forms.Label header;
    }
}

